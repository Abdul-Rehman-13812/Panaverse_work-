"use strict";
// question 15 
let gustarr = ["Abdul rehman ", "Abdullah", "Arham"];
const message2 = "Salam, {name}! you are invited for  dinner this night. ";
console.log(gustarr[2], "cannt make the dinner");
let new_person = "Abdul karim";
console.log("replace  ", gustarr[2], "with", new_person);
for (const name of gustarr) {
    const pmesage = message2.replace("{name}", name);
    console.log(pmesage);
}
console.log("*------------*");
//question 16 
const gustarr1 = ["Abdul rehman ", "Abdullah", "Arham"];
const message4 = "Sorry! we can invite only two people for dinner for space problem";
console.log(message4);
gustarr1.pop();
const message5 = "salam!  you are still invited for this dinner ";
console.log(message5);
console.log(gustarr1);
// const message5:string = "salam! {name} you are still invited for this dinner "
// for(const name of gustarr1){
//     const pmesage = message5.replace ("{name}",name);
//     console.log(pmesage);
// }
console.log("*------------*");
//question 17
let arrplaces = ["esraeeal", "libia", "bangadash ", "itly", "france"];
console.log(arrplaces);
